import { Component, OnInit } from '@angular/core';
import { CdkDragDrop, moveItemInArray, transferArrayItem, CdkDragHandle } from '@angular/cdk/drag-drop';
import { saveAs } from 'file-saver';

interface ToDo { //JSON format for data
  position: number;
  indent: number;
  value: string;
  id: number;
  style: string;
  pad: string;
}

const Todolist: ToDo[] = []; //empty list declaration
@Component({
  selector: 'app-datatable',
  templateUrl: './datatable.component.html',
  styleUrls: ['./datatable.component.css']
})
export class DatatableComponent implements OnInit {

  constructor() { }
  todo = Todolist;
  selectedFile: File //for initializing uploaded file.
  color = ['lightblue', 'black', 'red', 'yellow', 'orange', 'pink', 'darkgray']; //for colors during indentation

  onChangeEvent(i) { //template function to add the very first data in list
    if (i === 0) {
      var val = (<HTMLInputElement>document.getElementById("empty")).value; //empty is id of the initial empty template
      var len = this.todo.length;
      console.log(len)
      this.todo.push({
        'position': i + 1,
        'indent': 0,
        'value': val,
        'id': i + 1,
        'style': 'lightblue',
        'pad': '0px'
      });
    }
  }

  onChangeReplace(i) { //to replace the value of the text of an element in the list
    var len = this.todo.length;
    var value = (<HTMLInputElement>document.getElementById(this.todo[i].id.toString())).value;
    this.todo[i].value = value;
  }

  additem() { //adds the template to be filled 
    var len = this.todo.length;
    var id = 0;
    var ind = this.todo[len - 1].indent;
    this.todo.forEach((item, idx) => {
      if (item.id > id)
        id = item.id;
    });
    this.todo.push({
      'position': len + 1,
      'indent': ind,
      'value': '',
      'id': id + 1,
      'style': this.color[ind],
      'pad': (24 * ind).toString() + 'px'
    });
  }

  deleteitem(i) { //delete the parent and it's child nodes
    var ind = this.todo[i].indent;
    this.todo.splice(i, 1); //to delete the node
    while (this.todo[i].indent > ind && this.todo[i] !== undefined) //to delete all the children of the node
      this.todo.splice(i, 1);
  }

  indent(i) { //indentation function
    if (i > 0) {
      if (this.todo[i].indent >= 0 && (this.todo[i].indent <= this.todo[i - 1].indent)) {
        this.todo[i].indent += 1;
        this.todo[i].style = this.color[this.todo[i].indent]; //color changes using the inline ngStyle 
        this.todo[i].pad = (24 * this.todo[i].indent).toString() + 'px';
      }
    }
  }

  outdent(i) {
    if (this.todo[i].indent > 0) { //outdentation function
      this.todo[i].indent -= 1;
      this.todo[i].style = this.color[this.todo[i].indent];
      this.todo[i].pad = (24 * this.todo[i].indent).toString() + 'px';
    }
  }

  onDrop(event: CdkDragDrop<string[]>) { //drag drop function
    var prev = event.previousIndex;
    var cur = event.currentIndex;
    var i = prev + 1;
    var count = 1;

    while (true) {
      if (this.todo[i] !== undefined && this.todo[i].indent > this.todo[prev].indent) {
        count += 1;
        i += 1;
      }
      else
        break;
    }
    if (prev < cur) { //downshifting list
      for (var i = 0; i < count; i++)
        moveItemInArray(this.todo, prev, cur);
    }
    else {
      for (var i = 0; i < count; i++) { //upshiftinh list
        moveItemInArray(this.todo, prev, cur);
        prev++; cur++;
      }
    }
    this.todo.forEach((item, idx) => {
      item.position = idx + 1; //to change index of all the nodes below
    });
  }

  onFileChanged(event) { //load data into the todo list when file is uploaded
    this.selectedFile = event.target.files[0];
    const fileReader = new FileReader();
    fileReader.readAsText(this.selectedFile, "UTF-8");
    fileReader.onload = () => {
      this.todo = JSON.parse(<string>fileReader.result);
    }
    fileReader.onerror = (error) => {
      console.log(error);
    }
  }

  save() { //save the data to the PC using file-saver module of npm in JSON format
    const blob = new Blob([JSON.stringify(this.todo)], { type: 'application/json' });
    saveAs(blob, 'data.json');
  }
  ngOnInit(): void { }

}
